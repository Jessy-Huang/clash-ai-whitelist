// Clash Verge Rev Global Extend Script
// Managed by clash-ai-whitelist
// Purpose: proxy selected AI / algorithm-engineering services, DIRECT everything else.

const PREFERRED_GROUP = "__PREFERRED_GROUP__";

const EXACT_DOMAINS = [
  // OpenAI auth/challenge
  "challenges.cloudflare.com",

  // Gemini / Google AI
  "gemini.google.com",
  "aistudio.google.com",
  "ai.google.dev",
  "generativelanguage.googleapis.com",
  "accounts.google.com",
  "apis.google.com",
  "colab.research.google.com",

  // VS Code
  "marketplace.visualstudio.com",
  "update.code.visualstudio.com",
  "code.visualstudio.com",

  // NVIDIA AI
  "ngc.nvidia.com",
  "catalog.ngc.nvidia.com",
  "developer.nvidia.com"
];

const SUFFIX_DOMAINS = [
  // OpenAI / ChatGPT / Codex
  "chatgpt.com",
  "openai.com",
  "oaistatic.com",
  "oaiusercontent.com",
  "oaistatsig.com",
  "openaimerge.com",
  "workos.com",
  "workoscdn.com",

  // GitHub / Copilot / containers
  "github.com",
  "githubusercontent.com",
  "githubassets.com",
  "githubcopilot.com",
  "github.dev",
  "ghcr.io",

  // Hugging Face / Xet / LFS
  "huggingface.co",
  "hf.co",

  // Anthropic / Claude / Claude Code
  "claude.ai",
  "claude.com",
  "anthropic.com",

  // Gemini static resources
  "gstatic.com",
  "googleusercontent.com",
  "colab.google",

  // xAI / Grok
  "grok.com",
  "x.ai",

  // LLM / AI APIs
  "openrouter.ai",
  "together.ai",
  "groq.com",
  "mistral.ai",
  "replicate.com",
  "perplexity.ai",
  "cohere.com",

  // AI coding tools
  "cursor.com",
  "cursor.sh",
  "windsurf.com",
  "codeium.com",
  "sourcegraph.com",

  // VS Code assets
  "vsassets.io",

  // Docker / registries
  "docker.io",
  "docker.com",
  "dockerstatic.com",

  // NVIDIA NGC
  "nvcr.io",

  // Package registries
  "pypi.org",
  "pythonhosted.org",
  "npmjs.org",
  "npmjs.com",
  "crates.io",
  "anaconda.org",
  "conda.io",

  // ML / experiment tracking
  "wandb.ai",

  // GitLab
  "gitlab.com",
  "gitlab-static.net",

  // Cloud GPU / compute
  "runpod.io",
  "modal.com",
  "vast.ai",
  "lambda.ai",

  // Research / datasets
  "arxiv.org",
  "openreview.net",
  "paperswithcode.com",
  "semanticscholar.org",
  "kaggle.com",
  "kaggleusercontent.com",

  // ML frameworks / docs
  "pytorch.org",
  "tensorflow.org"
];

function groups(config) {
  return Array.isArray(config["proxy-groups"]) ? config["proxy-groups"] : [];
}

function groupExists(config, name) {
  return groups(config).some(g => g && g.name === name);
}

function chooseProxyGroup(config) {
  if (PREFERRED_GROUP && groupExists(config, PREFERRED_GROUP)) {
    return PREFERRED_GROUP;
  }

  const gs = groups(config);

  // Prefer a manual/select group whose name looks like a primary proxy selector.
  const namePatterns = [
    /选择节点/i,
    /节点选择/i,
    /代理节点/i,
    /proxy/i,
    /select/i,
    /manual/i
  ];

  for (const re of namePatterns) {
    const hit = gs.find(g => g && g.type === "select" && re.test(String(g.name || "")));
    if (hit) return hit.name;
  }

  // Otherwise use the first select group.
  const firstSelect = gs.find(g => g && g.type === "select" && g.name);
  if (firstSelect) return firstSelect.name;

  // Last fallback: first proxy group.
  const first = gs.find(g => g && g.name);
  return first ? first.name : null;
}

function main(config, profileName) {
  const proxyGroup = chooseProxyGroup(config);

  if (!proxyGroup) {
    console.log("[clash-ai-whitelist] No proxy group found; leaving config unchanged.");
    return config;
  }

  const managedRules = [
    ...EXACT_DOMAINS.map(d => `DOMAIN,${d},${proxyGroup}`),
    ...SUFFIX_DOMAINS.map(d => `DOMAIN-SUFFIX,${d},${proxyGroup}`),

    // Everything not explicitly whitelisted stays local/direct.
    "MATCH,DIRECT"
  ];

  config["rules"] = managedRules;

  console.log(
    `[clash-ai-whitelist] profile=${profileName || "unknown"} group=${proxyGroup} ` +
    `rules=${managedRules.length}`
  );

  return config;
}
